export const Menu = [
  {
    id: 0,
    title: 'หน้าแรก',
    pathname: '/home',
  },
  {
    id: 2,
    title: 'จองคิว',
    pathname: '/book-an-appointment',
  },
  {
    id: 3,
    title: 'ตรวจสอบคิว',
    pathname: '/check-book-an-appointment',
  },
  {
    id: 4,
    title: 'ลงทะเบียน',
    pathname: '/register',
  },
  {
    id: 5,
    title: 'เข้าสู่ระบบ',
    pathname: '/login',
  },
];
