import React from 'react';

function Footer() {
  return (
    <footer id="public">
      <div className="footer">
        <span>Created By HUGCODE CO.,LTD.</span>
      </div>
    </footer>
  );
}

export default Footer;
