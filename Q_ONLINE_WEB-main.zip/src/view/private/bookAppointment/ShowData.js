import React from 'react'

const ShowData = () => {
  return (
    <div>
      
    </div>
  )
}

export default ShowData
